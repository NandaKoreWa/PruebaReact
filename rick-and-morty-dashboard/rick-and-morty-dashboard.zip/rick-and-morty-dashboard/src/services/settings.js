export const API_URL = 'https://rickandmortyapi.com/api/'
export const PERSONAJES = 'character'
export const EPISODIOS = 'episode'
export const LOCALIZACIONES = 'location'
